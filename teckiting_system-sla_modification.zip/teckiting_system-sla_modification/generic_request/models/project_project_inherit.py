from odoo import models, fields, api


class ProjectProjectInherit(models.Model):
    _inherit = "project.project"
    
    
    ticket_count = fields.Integer(compute="_ticket_count")

    def _ticket_count(self):
        for rec in self :

            ticket_task = self.env['project.task'].search_count([('request_id','!=',False),('project_id','=',rec.id)])
            rec.ticket_count = ticket_task

    def open_tickets(self):
        return {
            'type':'ir.actions.act_window',
            'name':'Tickets',
            'res_model':'project.task',
            'domain':[('project_id','=',self.id),('request_id','!=',False)],
            'view_mode':'tree,form,kanban',
            'target':'current'

        }
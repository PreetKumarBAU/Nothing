Remove obsolete modules from settings page.
Obsolte modules are:
- `generic_request_action_condition`

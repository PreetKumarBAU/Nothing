Implemented Readmore / Readless functionality for request text and request response


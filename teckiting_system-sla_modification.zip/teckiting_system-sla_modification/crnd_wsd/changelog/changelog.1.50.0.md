Added mult-site support for requests

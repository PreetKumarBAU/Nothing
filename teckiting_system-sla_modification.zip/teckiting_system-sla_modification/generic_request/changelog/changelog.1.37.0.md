Fix Readmore feature: update state when images (that are in request text) loaded

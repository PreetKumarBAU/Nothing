Use different colors for deadline icon depending on deadline value

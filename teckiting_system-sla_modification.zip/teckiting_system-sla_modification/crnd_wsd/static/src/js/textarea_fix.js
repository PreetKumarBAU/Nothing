$(function() {
    $('#request_text').trumbowyg();
}); 
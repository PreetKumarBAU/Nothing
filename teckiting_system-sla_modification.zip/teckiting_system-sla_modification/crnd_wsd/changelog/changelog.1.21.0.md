[FIX] Use correct configuration for dialogs: make it possible to customize
colors of buttons via website theme.

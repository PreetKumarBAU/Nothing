Added wizard to manage tags on multiple objects.
This wizard available in *Actions* dropdown on objects list and form view


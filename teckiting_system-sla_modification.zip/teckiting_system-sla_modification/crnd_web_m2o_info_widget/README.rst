Many2one Info Widget
====================

#### Version 1.111.0
Added new request event types: 'author-changed' and 'partner-changed'.
 
from . import (
    generic_tag_model,
    generic_tag_model_mixin,
    generic_tag_category,
    generic_tag,
    generic_tag_mixin,
)

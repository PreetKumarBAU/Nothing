Add global settings:
- 'Automatically remove events older then',
- 'Event Live Time',
- 'Event Live Time Uom'
